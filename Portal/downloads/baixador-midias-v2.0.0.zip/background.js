const capturedVideosByTab = new Map();
const MAX_CAPTURED_PER_TAB = 250;
const VIDEO_EXT_RE = /\.(mp4|webm|ogv|ogg|mov|m4v|avi|mkv|3gp|ts|m3u8|mpd|m4s)(\?|#|$)/i;

chrome.runtime.onInstalled.addListener(() => {
  capturedVideosByTab.clear();
});

chrome.tabs?.onRemoved?.addListener((tabId) => {
  capturedVideosByTab.delete(tabId);
});

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    try {
      if (VIDEO_EXT_RE.test(details?.url || '')) {
        captureVideoRequest({ ...details, responseHeaders: [] });
      }
    } catch (error) {
      console.warn('Falha ao capturar URL de vídeo.', error);
    }
  },
  { urls: ['<all_urls>'], types: ['media', 'xmlhttprequest', 'other'] }
);

chrome.webRequest.onCompleted.addListener(
  (details) => {
    try {
      captureVideoRequest(details);
    } catch (error) {
      console.warn('Falha ao capturar requisição de vídeo.', error);
    }
  },
  { urls: ['<all_urls>'], types: ['media', 'xmlhttprequest', 'other'] },
  ['responseHeaders']
);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message?.type) return false;

  if (message.type === 'getCapturedVideos') {
    const tabId = Number(message.tabId);
    const items = Number.isFinite(tabId) ? (capturedVideosByTab.get(tabId) || []) : [];
    sendResponse({ ok: true, items });
    return false;
  }

  if (!['downloadImage', 'downloadVideo'].includes(message.type)) return false;

  (async () => {
    try {
      const result = message.type === 'downloadVideo'
        ? await downloadVideo(message)
        : await downloadImage(message);
      sendResponse({ ok: true, result });
    } catch (error) {
      console.error(error);
      sendResponse({ ok: false, error: error?.message || 'Erro inesperado no download.' });
    }
  })();

  return true;
});

function getHeader(headers = [], name) {
  const found = headers.find((header) => String(header.name || '').toLowerCase() === name.toLowerCase());
  return found?.value || '';
}

function getFilenameFromDisposition(disposition = '') {
  const value = String(disposition || '');
  const utf = value.match(/filename\*=UTF-8''([^;]+)/i);
  if (utf) {
    try { return decodeURIComponent(utf[1].replace(/["']/g, '')); } catch {}
  }
  const regular = value.match(/filename="?([^";]+)"?/i);
  return regular ? regular[1].trim() : '';
}

function isLikelyVideoRequest(details) {
  const url = details?.url || '';
  const contentType = getHeader(details?.responseHeaders || [], 'content-type').toLowerCase();
  if (details?.type === 'media') return true;
  if (VIDEO_EXT_RE.test(url)) return true;
  return /video\//i.test(contentType)
    || /mpegurl|dash\+xml|mp4|webm|quicktime|application\/octet-stream/i.test(contentType);
}

function captureVideoRequest(details) {
  if (!details || details.tabId < 0 || !details.url) return;
  if (!/^https?:/i.test(details.url)) return;
  if (!isLikelyVideoRequest(details)) return;

  const responseHeaders = details.responseHeaders || [];
  const mime = getHeader(responseHeaders, 'content-type');
  const length = Number(getHeader(responseHeaders, 'content-length') || 0) || 0;
  const dispositionName = getFilenameFromDisposition(getHeader(responseHeaders, 'content-disposition'));
  const item = {
    url: details.url,
    source: 'rede',
    width: 0,
    height: 0,
    title: dispositionName || '',
    name: dispositionName || '',
    mime,
    size: length,
    statusCode: details.statusCode || 0,
    timeStamp: details.timeStamp || Date.now()
  };

  const list = capturedVideosByTab.get(details.tabId) || [];
  const existing = list.findIndex((entry) => entry.url === item.url);
  if (existing >= 0) list.splice(existing, 1);
  list.unshift(item);
  if (list.length > MAX_CAPTURED_PER_TAB) list.length = MAX_CAPTURED_PER_TAB;
  capturedVideosByTab.set(details.tabId, list);
}

async function downloadVideo({ url, filename, tabId, pageUrl, format }) {
  if (!url) throw new Error('URL do vídeo não encontrada.');

  const finalName = normalizeDownloadVideoFilename(
    filename || `videos/video.${format && format !== 'video' ? format : 'mp4'}`,
    format,
    url
  );

  // Blob/data só existem dentro do contexto da página.
  if (/^blob:|^data:video\//i.test(url)) {
    return downloadFromPageContext({ tabId, url, filename: finalName });
  }

  // Para Shopee/HTTP direto, não usamos fallback por <a>, porque isso pode apenas abrir o vídeo em outra aba.
  // Primeiro baixamos o binário via fetch e entregamos ao chrome.downloads como arquivo local.
  if (/^https?:/i.test(url)) {
    try {
      return await downloadHttpVideoAsBlob({ url, filename: finalName, pageUrl, format });
    } catch (error) {
      console.warn('Download via blob falhou. Tentando downloads.download direto, sem abrir aba.', error);
      return chrome.downloads.download({
        url,
        filename: finalName,
        saveAs: false,
        conflictAction: 'uniquify'
      });
    }
  }

  throw new Error('Formato de URL de vídeo não suportado.');
}

function normalizeDownloadVideoFilename(filename, format = '', url = '') {
  let clean = String(filename || 'videos/video.mp4')
    .replace(/[\\:*?"<>|]+/g, '-')
    .replace(/\s+/g, ' ')
    .trim();

  const lowerFormat = String(format || '').toLowerCase();
  const urlLooksMp4 = /\.mp4(\?|#|$)/i.test(url) || /shopee|vod|mms/i.test(url);
  const shouldBeMp4 = ['mp4', 'http', 'video', ''].includes(lowerFormat) || urlLooksMp4;

  if (shouldBeMp4) {
    clean = clean.replace(/\.(m3u8|ts|m4s|webm|mov|m4v|ogv|ogg|php|html?|json|txt)$/i, '.mp4');
    if (!/\.mp4$/i.test(clean)) clean += '.mp4';
  }

  if (!clean.includes('/')) clean = `videos/${clean}`;
  return clean;
}

async function downloadHttpVideoAsBlob({ url, filename, pageUrl, format }) {
  const response = await fetch(url, {
    credentials: 'include',
    cache: 'no-store',
    redirect: 'follow'
  });

  if (!response.ok) throw new Error(`Falha ao buscar vídeo: HTTP ${response.status}`);

  const contentType = (response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  const blob = await response.blob();
  if (!blob.size) throw new Error('Arquivo de vídeo vazio.');

  const looksLikeVideo = /^video\//i.test(contentType)
    || /mp4|webm|quicktime|octet-stream/i.test(contentType)
    || /\.mp4(\?|#|$)/i.test(response.url || url)
    || ['mp4', 'http', 'video'].includes(String(format || '').toLowerCase());

  if (!looksLikeVideo) {
    throw new Error(`A URL retornou ${contentType || 'conteúdo desconhecido'}, não vídeo.`);
  }

  const mime = /^video\//i.test(contentType) ? contentType : 'video/mp4';
  const fixedBlob = blob.type === mime ? blob : new Blob([await blob.arrayBuffer()], { type: mime });
  const dataUrl = await blobToDataUrl(fixedBlob);
  const finalName = normalizeDownloadVideoFilename(filename, mime.includes('webm') ? 'webm' : 'mp4', response.url || url);

  return chrome.downloads.download({
    url: dataUrl,
    filename: finalName,
    saveAs: false,
    conflictAction: 'uniquify'
  });
}

function buildDownloadHeaders(pageUrl, targetUrl) {
  const headers = [];
  try {
    if (pageUrl && /^https?:/i.test(pageUrl)) {
      headers.push({ name: 'Referer', value: pageUrl });
      headers.push({ name: 'Origin', value: new URL(pageUrl).origin });
    } else if (targetUrl && /^https?:/i.test(targetUrl)) {
      headers.push({ name: 'Origin', value: new URL(targetUrl).origin });
    }
  } catch {}
  return headers;
}

async function downloadFromPageContext({ tabId, url, filename }) {
  const numericTabId = Number(tabId);
  if (!Number.isFinite(numericTabId)) throw new Error('Não foi possível acessar a aba da página para baixar este vídeo.');

  const safeName = String(filename || 'video.mp4').split('/').filter(Boolean).pop() || 'video.mp4';

  let injected;
  try {
    injected = await chrome.scripting.executeScript({
      target: { tabId: numericTabId },
      world: 'MAIN',
      func: pageContextDownload,
      args: [url, safeName]
    });
  } catch (error) {
    injected = await chrome.scripting.executeScript({
      target: { tabId: numericTabId },
      func: pageContextDownload,
      args: [url, safeName]
    });
  }

  const result = injected?.[0]?.result;
  if (!result?.ok) throw new Error(result?.error || 'O navegador bloqueou o download pelo player da página.');
  return result;
}

async function pageContextDownload(url, filename) {
  try {
    let objectUrl = '';
    let href = url;

    try {
      const response = await fetch(url, { credentials: 'include', cache: 'no-store' });
      if (response.ok) {
        const blob = await response.blob();
        if (blob.size) {
          const mime = blob.type || 'video/mp4';
          const fixedBlob = mime ? blob : new Blob([await blob.arrayBuffer()], { type: 'video/mp4' });
          objectUrl = URL.createObjectURL(fixedBlob);
          href = objectUrl;
        }
      }
    } catch (error) {
      // Se não der para fazer fetch, ainda tentamos o link original.
      // Para blob: normalmente o fetch funciona; para servidores com bloqueio, pode falhar.
      console.warn('Fetch no contexto da página falhou, tentando href original.', error);
    }

    const a = document.createElement('a');
    a.href = href;
    a.download = filename || 'video.mp4';
    a.rel = 'noopener';
    a.style.display = 'none';
    document.documentElement.appendChild(a);
    a.click();
    setTimeout(() => {
      a.remove();
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    }, 5000);
    return { ok: true, method: objectUrl ? 'page-blob-download' : 'page-anchor' };
  } catch (error) {
    return { ok: false, error: error?.message || String(error) };
  }
}


async function downloadImage({ url, filename, format, convertWebpToJpg, resizeTo1200 }) {
  const normalizedFormat = String(format || '').toLowerCase();
  const isWebp = normalizedFormat === 'webp' || /\.webp(\?|#|$)/i.test(url);
  let finalName = filename || 'imagens/imagem.jpg';
  const needsCanvas = Boolean(resizeTo1200) || Boolean(convertWebpToJpg && isWebp);

  if (!needsCanvas) {
    return chrome.downloads.download({
      url,
      filename: finalName,
      saveAs: false,
      conflictAction: 'uniquify'
    });
  }

  try {
    const response = url.startsWith('data:')
      ? await fetch(url)
      : await fetch(url, { credentials: 'include', cache: 'no-store' });

    if (!response.ok) throw new Error(`Falha ao buscar imagem: HTTP ${response.status}`);

    const originalBlob = await response.blob();
    const outputType = getOutputType(normalizedFormat, isWebp, resizeTo1200);
    const convertedBlob = await convertBlobOnCanvas(originalBlob, {
      type: outputType,
      quality: 0.92,
      width: resizeTo1200 ? 1200 : null,
      height: resizeTo1200 ? 1200 : null
    });

    finalName = updateFilenameExtension(finalName, outputType);
    const dataUrl = await blobToDataUrl(convertedBlob);

    return chrome.downloads.download({
      url: dataUrl,
      filename: finalName,
      saveAs: false,
      conflictAction: 'uniquify'
    });
  } catch (error) {
    console.warn('Não foi possível processar a imagem, baixando o arquivo original.', error);
    return chrome.downloads.download({
      url,
      filename: fallbackOriginalName(finalName, normalizedFormat, isWebp),
      saveAs: false,
      conflictAction: 'uniquify'
    });
  }
}

function getOutputType(format, isWebp, resizeTo1200) {
  if (isWebp) return 'image/jpeg';
  if (resizeTo1200 && format === 'png') return 'image/png';
  return 'image/jpeg';
}

function updateFilenameExtension(filename, mimeType) {
  const ext = mimeType === 'image/png' ? '.png' : '.jpg';
  return filename.match(/\.[a-z0-9]{2,5}$/i)
    ? filename.replace(/\.[a-z0-9]{2,5}$/i, ext)
    : `${filename}${ext}`;
}

function fallbackOriginalName(filename, format, isWebp) {
  if (isWebp && !/\.webp$/i.test(filename)) {
    return filename.replace(/\.[a-z0-9]{2,5}$/i, '.webp');
  }
  if (!filename.match(/\.[a-z0-9]{2,5}$/i) && format) {
    const ext = format === 'jpeg' ? 'jpg' : format;
    return `${filename}.${ext}`;
  }
  return filename;
}

async function convertBlobOnCanvas(blob, options = {}) {
  const bitmap = await createImageBitmap(blob);
  const targetWidth = options.width || bitmap.width;
  const targetHeight = options.height || bitmap.height;
  const outputType = options.type || 'image/jpeg';
  const canvas = new OffscreenCanvas(targetWidth, targetHeight);
  const ctx = canvas.getContext('2d', { alpha: outputType === 'image/png' });

  if (outputType !== 'image/png') {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  } else {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }

  if (options.width && options.height) {
    const scale = Math.min(targetWidth / bitmap.width, targetHeight / bitmap.height);
    const drawWidth = Math.round(bitmap.width * scale);
    const drawHeight = Math.round(bitmap.height * scale);
    const offsetX = Math.round((targetWidth - drawWidth) / 2);
    const offsetY = Math.round((targetHeight - drawHeight) / 2);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(bitmap, offsetX, offsetY, drawWidth, drawHeight);
  } else {
    ctx.drawImage(bitmap, 0, 0);
  }

  if (typeof bitmap.close === 'function') bitmap.close();

  return canvas.convertToBlob({ type: outputType, quality: options.quality || 0.92 });
}

async function blobToDataUrl(blob) {
  const buffer = await blob.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = '';

  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }

  return `data:${blob.type || 'application/octet-stream'};base64,${btoa(binary)}`;
}

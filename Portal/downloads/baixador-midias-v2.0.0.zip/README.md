# Baixador de Imagens e Vídeos

Extensão para Chrome/Edge focada em baixar mídias de páginas de marketplace.

## Recursos principais

- Aba de imagens com filtro inteligente para ocultar ícones, SVG, backgrounds e imagens auxiliares.
- Aba de vídeos com agrupamento inteligente.
- Mercado Livre: captura HLS/M3U8, escolhe a melhor qualidade, baixa os segmentos e gera MP4 quando possível.
- Shopee: captura vídeos HTTP/MP4, agrupa duplicados em um único card e força o download como arquivo .mp4.
- Download individual, dos itens selecionados ou dos itens visíveis.
- Conversão automática de WEBP para JPG no download de imagens.
- Opção para ajustar imagens baixadas para 1200x1200 px.

## Como usar na Shopee

1. Instale a extensão.
2. Abra ou recarregue o anúncio da Shopee.
3. Dê play no vídeo por alguns segundos.
4. Abra a extensão e entre na aba Vídeos.
5. Clique em atualizar.
6. Deve aparecer somente o vídeo principal agrupado.
7. Clique em Baixar para salvar o arquivo em .mp4.

## Observações

Vídeos com DRM, criptografia ou bloqueio forte do servidor podem não ser baixáveis por uma extensão comum. Para vídeos HTTP/MP4 comuns da Shopee, esta versão tenta baixar o binário diretamente em vez de abrir uma nova aba com o player.

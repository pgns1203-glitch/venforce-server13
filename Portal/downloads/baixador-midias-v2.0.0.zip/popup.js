const state = {
  type: 'images',
  images: [],
  videos: [],
  filtered: [],
  selected: {
    images: new Set(),
    videos: new Set()
  },
  loaded: {
    images: false,
    videos: false
  },
  loading: false,
  tabId: null,
  pageUrl: ''
};

const FORMAT_OPTIONS = {
  images: [
    ['', 'Todos'],
    ['jpg', 'JPG/JPEG'],
    ['png', 'PNG'],
    ['webp', 'WEBP'],
    ['gif', 'GIF'],
    ['svg', 'SVG'],
    ['avif', 'AVIF']
  ],
  videos: [
    ['', 'Todos'],
    ['m3u8', 'M3U8/HLS'],
    ['mp4', 'MP4/HTTP'],
    ['webm', 'WEBM'],
    ['http', 'HTTP direto']
  ]
};

const els = {
  refreshBtn: document.getElementById('refreshBtn'),
  imagesTab: document.getElementById('imagesTab'),
  videosTab: document.getElementById('videosTab'),
  urlFilter: document.getElementById('urlFilter'),
  formatFilter: document.getElementById('formatFilter'),
  minWidth: document.getElementById('minWidth'),
  minHeight: document.getElementById('minHeight'),
  minPixels: document.getElementById('minPixels'),
  resize1200: document.getElementById('resize1200'),
  resizeOption: document.getElementById('resizeOption'),
  showAuxImages: document.getElementById('showAuxImages'),
  auxImagesOption: document.getElementById('auxImagesOption'),
  clearFiltersBtn: document.getElementById('clearFiltersBtn'),
  matchingCount: document.getElementById('matchingCount'),
  filteredCount: document.getElementById('filteredCount'),
  selectedCount: document.getElementById('selectedCount'),
  selectAllVisible: document.getElementById('selectAllVisible'),
  downloadSelectedBtn: document.getElementById('downloadSelectedBtn'),
  downloadVisibleBtn: document.getElementById('downloadVisibleBtn'),
  gallery: document.getElementById('gallery'),
  message: document.getElementById('message')
};

function currentItems() {
  return state[state.type];
}

function currentSelected() {
  return state.selected[state.type];
}

function itemLabel(plural = true) {
  if (state.type === 'videos') return plural ? 'vídeos' : 'vídeo';
  return plural ? 'imagens' : 'imagem';
}

function setMessage(text, type = '') {
  els.message.textContent = text;
  els.message.className = `message ${type}`.trim();
}

function populateFormatOptions() {
  const currentValue = els.formatFilter.value;
  els.formatFilter.innerHTML = '';

  FORMAT_OPTIONS[state.type].forEach(([value, label]) => {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = label;
    els.formatFilter.appendChild(option);
  });

  const validValues = FORMAT_OPTIONS[state.type].map(([value]) => value);
  els.formatFilter.value = validValues.includes(currentValue) ? currentValue : '';
}

function updateTabUI() {
  els.imagesTab.classList.toggle('active', state.type === 'images');
  els.videosTab.classList.toggle('active', state.type === 'videos');
  els.resizeOption.style.display = state.type === 'images' ? 'inline-flex' : 'none';
  if (els.auxImagesOption) els.auxImagesOption.style.display = state.type === 'images' ? 'inline-flex' : 'none';
  els.downloadVisibleBtn.textContent = state.type === 'videos' ? 'Baixar vídeos visíveis' : 'Baixar visíveis';
  els.downloadSelectedBtn.textContent = state.type === 'videos' ? 'Baixar vídeos selecionados' : 'Baixar selecionadas';
  els.refreshBtn.title = state.type === 'videos' ? 'Atualizar vídeos' : 'Atualizar imagens';
  populateFormatOptions();
}

function normalizeImageFormat(url, mime = '') {
  const lowerMime = (mime || '').toLowerCase();
  if (lowerMime.includes('jpeg')) return 'jpg';
  if (lowerMime.includes('png')) return 'png';
  if (lowerMime.includes('webp')) return 'webp';
  if (lowerMime.includes('gif')) return 'gif';
  if (lowerMime.includes('svg')) return 'svg';
  if (lowerMime.includes('avif')) return 'avif';

  try {
    const path = new URL(url).pathname.toLowerCase();
    const match = path.match(/\.([a-z0-9]{2,5})$/);
    if (!match) return 'img';
    return match[1] === 'jpeg' ? 'jpg' : match[1];
  } catch {
    return 'img';
  }
}

function normalizeVideoFormat(url, mime = '') {
  const lowerMime = (mime || '').toLowerCase();
  if (lowerMime.includes('mp4')) return 'mp4';
  if (lowerMime.includes('webm')) return 'webm';
  if (lowerMime.includes('quicktime')) return 'mov';
  if (lowerMime.includes('mpegurl') || lowerMime.includes('x-mpegurl')) return 'm3u8';
  if (lowerMime.includes('ogg')) return 'ogg';

  try {
    const path = new URL(url).pathname.toLowerCase();
    const match = path.match(/\.([a-z0-9]{2,5})$/);
    if (!match) return 'video';
    const ext = match[1];
    if (ext === 'ogv') return 'ogg';
    return ext;
  } catch {
    return 'video';
  }
}

function getDisplayName(url, index, fallbackPrefix, format) {
  try {
    const decoded = decodeURIComponent(new URL(url).pathname.split('/').filter(Boolean).pop() || '');
    const base = decoded || `${fallbackPrefix}-${String(index + 1).padStart(3, '0')}.${format || 'jpg'}`;
    return base.length > 90 ? base.slice(0, 86) + '...' : base;
  } catch {
    return `${fallbackPrefix}-${String(index + 1).padStart(3, '0')}.${format || 'jpg'}`;
  }
}

function getImageSize(url) {
  return new Promise((resolve) => {
    if (url.startsWith('data:image/svg')) {
      resolve({ width: 0, height: 0 });
      return;
    }

    const img = new Image();
    const done = (size) => {
      img.onload = null;
      img.onerror = null;
      resolve(size);
    };

    img.onload = () => done({ width: img.naturalWidth || 0, height: img.naturalHeight || 0 });
    img.onerror = () => done({ width: 0, height: 0 });
    img.referrerPolicy = 'no-referrer-when-downgrade';
    img.src = url;
  });
}


function isAuxiliaryImage(item, format, width, height) {
  const source = String(item?.source || '').toLowerCase();
  const url = String(item?.url || '').toLowerCase();
  const alt = String(item?.alt || '').toLowerCase();
  const pixels = Number(width || 0) * Number(height || 0);
  const text = `${url} ${alt} ${source}`;

  if (format === 'svg') return { auxiliary: true, reason: 'SVG' };
  if (/background|border-image|list-style-image/.test(source)) return { auxiliary: true, reason: 'background' };
  if (/sprite|favicon|icon|logo|placeholder|loading|spinner|pixel|tracking|analytics|badge|seal|star|rating|close|arrow|chevron|loader|progress|feedback|settings|business|balance|market|product-bg|diagnose|example|frame|wU6Fh/i.test(text)) {
    return { auxiliary: true, reason: 'ícone/interface' };
  }

  if (width && height) {
    if (width < 180 || height < 180) return { auxiliary: true, reason: 'pequena' };
    if (pixels && pixels < 60000) return { auxiliary: true, reason: 'baixa resolução' };
  }

  return { auxiliary: false, reason: '' };
}

function shouldShowAuxiliaryImages() {
  return Boolean(els.showAuxImages?.checked);
}

function getVideoMetadata(url) {
  return new Promise((resolve) => {
    if (!url || url.startsWith('data:') || url.startsWith('blob:') || /\.m3u8(\?|#|$)/i.test(url)) {
      resolve({ width: 0, height: 0, duration: 0 });
      return;
    }

    const video = document.createElement('video');
    let finished = false;
    const timer = setTimeout(() => done({ width: 0, height: 0, duration: 0 }), 4500);

    function done(meta) {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      video.onloadedmetadata = null;
      video.onerror = null;
      video.removeAttribute('src');
      video.load();
      resolve(meta);
    }

    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;
    video.crossOrigin = 'anonymous';
    video.onloadedmetadata = () => done({
      width: video.videoWidth || 0,
      height: video.videoHeight || 0,
      duration: Number.isFinite(video.duration) ? video.duration : 0
    });
    video.onerror = () => done({ width: 0, height: 0, duration: 0 });
    video.src = url;
  });
}

function collectImagesInPage() {
  const results = [];
  const seen = new Set();

  function absoluteUrl(raw) {
    if (!raw) return '';
    const clean = String(raw).trim().replace(/^['"]|['"]$/g, '');
    if (!clean || clean === 'none' || clean.startsWith('chrome-extension:')) return '';
    try {
      return new URL(clean, document.baseURI).href;
    } catch {
      return '';
    }
  }

  function add(rawUrl, source, width = 0, height = 0, alt = '', mime = '') {
    const url = absoluteUrl(rawUrl);
    if (!url) return;
    if (!/^(https?:|data:image\/|blob:)/i.test(url)) return;
    if (seen.has(url)) return;
    seen.add(url);
    results.push({ url, source, width: Number(width) || 0, height: Number(height) || 0, alt: alt || '', mime: mime || '' });
  }

  function parseSrcset(srcset) {
    return String(srcset || '')
      .split(',')
      .map((part) => part.trim().split(/\s+/)[0])
      .filter(Boolean);
  }

  function parseCssUrls(value) {
    const urls = [];
    const re = /url\((['"]?)(.*?)\1\)/g;
    let match;
    while ((match = re.exec(String(value || ''))) !== null) {
      urls.push(match[2]);
    }
    return urls;
  }

  document.querySelectorAll('img').forEach((img) => {
    add(img.currentSrc || img.src, 'img', img.naturalWidth, img.naturalHeight, img.alt);
    parseSrcset(img.getAttribute('srcset')).forEach((src) => add(src, 'srcset', 0, 0, img.alt));
    add(img.getAttribute('data-src'), 'data-src', 0, 0, img.alt);
    add(img.getAttribute('data-original'), 'data-original', 0, 0, img.alt);
    add(img.getAttribute('data-lazy-src'), 'data-lazy-src', 0, 0, img.alt);
  });

  document.querySelectorAll('source[srcset]').forEach((source) => {
    parseSrcset(source.getAttribute('srcset')).forEach((src) => add(src, 'picture/srcset', 0, 0, '', source.type));
  });

  document.querySelectorAll('a[href]').forEach((a) => {
    const href = a.getAttribute('href');
    if (/\.(avif|bmp|gif|jpe?g|png|svg|webp)(\?.*)?$/i.test(href || '')) {
      add(href, 'link', 0, 0, a.textContent || '');
    }
  });

  document.querySelectorAll('*').forEach((el) => {
    const style = getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    parseCssUrls(style.backgroundImage).forEach((url) => add(url, 'background', rect.width, rect.height));
    parseCssUrls(style.borderImageSource).forEach((url) => add(url, 'border-image', rect.width, rect.height));
    parseCssUrls(style.listStyleImage).forEach((url) => add(url, 'list-style-image', rect.width, rect.height));
  });

  return results;
}

function collectVideosInPage() {
  const results = [];
  const seen = new Set();
  const videoExtPattern = /\.(mp4|webm|ogv|ogg|mov|m4v|avi|mkv|3gp|ts|m3u8|mpd)(\?.*)?$/i;
  const serializedVideoUrlPattern = /(https?:\\?\/\\?\/[^"'\s<>\\]+?\.(?:mp4|webm|ogv|ogg|mov|m4v|avi|mkv|3gp|ts|m3u8|mpd)(?:\?[^"'\s<>\\]*)?)/gi;
  const storageVideoPattern = /(https?:\\?\/\\?\/[^"'\s<>\\]+?(?:video|mlvideo|stream|media|vod|play|shopee)[^"'\s<>\\]*?)/gi;

  function cleanupRaw(raw) {
    if (!raw) return '';
    let clean = String(raw).trim().replace(/^['"]|['"]$/g, '');
    clean = clean
      .replace(/\\u002F/gi, '/')
      .replace(/\\\//g, '/')
      .replace(/&amp;/g, '&')
      .replace(/\\u0026/gi, '&')
      .replace(/\\u003D/gi, '=')
      .replace(/\\u003F/gi, '?');
    try { clean = decodeURIComponent(clean); } catch {}
    return clean;
  }

  function absoluteUrl(raw) {
    const clean = cleanupRaw(raw);
    if (!clean || clean === 'none' || clean.startsWith('chrome-extension:')) return '';
    try {
      return new URL(clean, document.baseURI).href;
    } catch {
      return '';
    }
  }

  function getBestVideoPoster() {
    const candidates = [];

    function addPoster(raw, source, score = 0, element = null) {
      const url = absoluteUrl(raw);
      if (!url || !/^(https?:|data:image\/|blob:)/i.test(url)) return;
      if (/\.svg(\?|#|$)/i.test(url)) score -= 1000;

      const text = `${url} ${source} ${element?.alt || ''} ${element?.title || ''}`;
      if (/video|poster|thumb|thumbnail|preview|play/i.test(text)) score += 5000;
      if (/logo|sprite|icon|avatar|brand/i.test(text)) score -= 5000;

      if (element) {
        const rect = element.getBoundingClientRect?.();
        const width = Number(element.naturalWidth || rect?.width || element.width || 0) || 0;
        const height = Number(element.naturalHeight || rect?.height || element.height || 0) || 0;
        score += Math.min(width * height, 2000000) / 1000;
        if (width < 120 || height < 120) score -= 1200;
      }

      candidates.push({ url, score });
    }

    document.querySelectorAll('video[poster]').forEach((video) => {
      addPoster(video.getAttribute('poster'), 'video-poster', 10000, video);
    });

    document.querySelectorAll('meta[property="og:image"], meta[property="og:image:secure_url"], meta[name="twitter:image"], meta[name="twitter:image:src"], link[rel~="image_src"]').forEach((el) => {
      addPoster(el.getAttribute('content') || el.getAttribute('href'), 'meta-image', 3500, null);
    });

    document.querySelectorAll('img').forEach((img) => {
      const raw = img.currentSrc || img.src || img.getAttribute('data-src') || img.getAttribute('data-original') || img.getAttribute('data-lazy-src');
      addPoster(raw, 'page-image', 0, img);
    });

    candidates.sort((a, b) => b.score - a.score);
    return candidates[0]?.url || '';
  }

  const fallbackPoster = getBestVideoPoster();

  function add(rawUrl, source, width = 0, height = 0, title = '', mime = '', poster = '', size = 0) {
    const url = absoluteUrl(rawUrl);
    if (!url) return;
    if (!/^(https?:|blob:|data:video\/)/i.test(url)) return;
    if (seen.has(url)) return;
    seen.add(url);
    results.push({
      url,
      source,
      width: Number(width) || 0,
      height: Number(height) || 0,
      title: title || '',
      mime: mime || '',
      poster: absoluteUrl(poster) || fallbackPoster,
      size: Number(size) || 0
    });
  }

  function addFromText(text, source) {
    const normalized = cleanupRaw(text || '');
    if (!normalized) return;

    let match;
    serializedVideoUrlPattern.lastIndex = 0;
    while ((match = serializedVideoUrlPattern.exec(normalized)) !== null) {
      add(match[1], source, 0, 0, document.title || '');
    }

    // Alguns players guardam URLs sem extensão em campos com nomes de vídeo.
    // Para evitar falsos positivos demais, só aceitamos domínios comuns de mídia/CDN ou URLs com pistas fortes.
    storageVideoPattern.lastIndex = 0;
    while ((match = storageVideoPattern.exec(normalized)) !== null) {
      const candidate = cleanupRaw(match[1]).replace(/[),;]+$/, '');
      if (/mlstatic|mercadolibre|mercadolivre|shopee|shp\.ee|cloudfront|akamai|googlevideo|vimeo|jwplayer|cdn|media|vod|mms/i.test(candidate)) {
        add(candidate, source, 0, 0, document.title || '');
      }
    }
  }

  document.querySelectorAll('video').forEach((video) => {
    const title = video.getAttribute('title') || video.getAttribute('aria-label') || video.getAttribute('alt') || '';
    const width = video.videoWidth || video.getAttribute('width') || video.clientWidth || 0;
    const height = video.videoHeight || video.getAttribute('height') || video.clientHeight || 0;
    const poster = video.getAttribute('poster') || '';

    add(video.currentSrc || video.src, 'video/player', width, height, title, video.type || '', poster);

    video.querySelectorAll('source[src]').forEach((source) => {
      add(source.getAttribute('src'), 'video/source', width, height, title, source.getAttribute('type') || '', poster);
    });

    ['data-src', 'data-video', 'data-mp4', 'data-webm', 'data-original', 'data-hls', 'data-stream'].forEach((attr) => {
      add(video.getAttribute(attr), attr, width, height, title, '', poster);
    });
  });

  document.querySelectorAll('source[src]').forEach((source) => {
    const type = source.getAttribute('type') || '';
    const src = source.getAttribute('src') || '';
    if (/video|mpegurl|dash/i.test(type) || videoExtPattern.test(src)) {
      add(src, 'source', 0, 0, '', type);
    }
  });

  document.querySelectorAll('a[href]').forEach((a) => {
    const href = a.getAttribute('href') || '';
    if (videoExtPattern.test(href)) {
      add(href, 'link', 0, 0, a.textContent || '', '');
    }
  });

  document.querySelectorAll('[src], [href], [data-src], [data-video], [data-mp4], [data-webm], [data-original], [data-hls], [data-stream]').forEach((el) => {
    ['src', 'href', 'data-src', 'data-video', 'data-mp4', 'data-webm', 'data-original', 'data-hls', 'data-stream'].forEach((attr) => {
      const value = el.getAttribute(attr) || '';
      if (videoExtPattern.test(value) || /video|stream|m3u8|mp4/i.test(attr + ' ' + value)) {
        add(value, attr, 0, 0, el.getAttribute('title') || el.textContent || '', el.getAttribute('type') || '');
      }
    });
  });

  document.querySelectorAll('meta[property="og:video"], meta[property="og:video:url"], meta[property="og:video:secure_url"], meta[name="twitter:player:stream"], meta[name="twitter:player"]').forEach((meta) => {
    add(meta.getAttribute('content'), 'meta', 0, 0, document.title || '', meta.getAttribute('type') || '');
  });

  try {
    performance.getEntriesByType('resource').forEach((entry) => {
      const name = entry.name || '';
      if (videoExtPattern.test(name) || /video|media|stream|m3u8|mp4/i.test(name) || entry.initiatorType === 'video') {
        add(name, 'rede/performance', 0, 0, document.title || '', '', '', entry.transferSize || entry.encodedBodySize || 0);
      }
    });
  } catch {}

  document.querySelectorAll('script').forEach((script) => {
    const text = script.textContent || script.innerText || '';
    if (/mp4|webm|m3u8|video|stream|mlvideo|mlstatic|shopee|vod|mms/i.test(text)) addFromText(text, 'script');
  });

  // Busca final em atributos de elementos, sem varrer todo o HTML para manter o popup leve.
  document.querySelectorAll('*').forEach((el) => {
    for (const attr of el.attributes || []) {
      const value = attr.value || '';
      if (/mp4|webm|m3u8|video|stream|mlvideo|mlstatic|shopee|vod|mms/i.test(value)) addFromText(value, `atributo/${attr.name}`);
    }
  });

  const hasDirectDownloadable = results.some((item) => /^(https?:|data:video\/)/i.test(item.url) && !/\.m4s(\?|#|$)|\.ts(\?|#|$)/i.test(item.url));

  // Em muitos players, inclusive anúncios do Mercado Livre, o elemento <video> usa blob: de MediaSource.
  // Esse endereço interno costuma falhar no downloads.download. Quando achamos URL real, escondemos o blob.
  if (hasDirectDownloadable) {
    return results.filter((item) => !/^blob:/i.test(item.url));
  }

  return results;
}
function mergeVideoCandidates(...groups) {
  const byUrl = new Map();

  groups.flat().forEach((item) => {
    if (!item?.url) return;
    const url = item.url;
    const previous = byUrl.get(url);
    if (!previous || scoreVideoCandidate(item) > scoreVideoCandidate(previous)) {
      byUrl.set(url, item);
    }
  });

  let list = [...byUrl.values()];
  const hasBetterThanBlob = list.some((item) => /^https?:/i.test(item.url) && !/\.(m4s|ts)(\?|#|$)/i.test(item.url));
  if (hasBetterThanBlob) {
    list = list.filter((item) => !/^blob:/i.test(item.url) && !/\.(m4s|ts)(\?|#|$)/i.test(item.url));
  }

  return list.sort((a, b) => scoreVideoCandidate(b) - scoreVideoCandidate(a));
}

async function prepareVideoCandidates(...groups) {
  const merged = mergeVideoCandidates(...groups);
  const hls = await collapseHlsCandidates(merged);
  const directHttp = collapseDirectHttpVideoCandidates(merged);

  // Mercado Livre: mantém o comportamento focado em HLS agrupado.
  if (/mercadolivre|mercadolibre/i.test(state.pageUrl || '') && hls.length) {
    return hls.slice(0, 1);
  }

  // Shopee: mostra somente um card, escolhendo o melhor candidato HTTP/MP4 real.
  // Isso evita dezenas de URLs duplicadas/candidatas da rede e deixa a ação de baixar direta.
  if (/shopee|shp\.ee/i.test(state.pageUrl || '')) {
    const bestDirect = pickBestShopeeHttpVideo(directHttp.length ? directHttp : merged.filter(isDirectHttpVideoCandidate));
    if (bestDirect) return [bestDirect];
    if (hls.length) return hls.slice(0, 1);
    return [];
  }

  const combined = mergeVideoCandidates([...hls, ...directHttp]);
  return combined.filter(isDisplayableVideoCandidate);
}

function pickBestShopeeHttpVideo(items) {
  const candidates = (items || [])
    .filter(isDirectHttpVideoCandidate)
    .map((item) => ({
      ...item,
      type: 'videos',
      format: 'mp4',
      source: 'HTTP Shopee MP4',
      name: buildDirectVideoName({ ...item, format: 'mp4' }),
      alt: item.alt || item.title || 'Vídeo principal da Shopee'
    }))
    .sort((a, b) => scoreDirectHttpCandidate(b) - scoreDirectHttpCandidate(a));

  return candidates[0] || null;
}

function isDisplayableVideoCandidate(item) {
  return isRawHlsCandidate(item) || isDirectHttpVideoCandidate(item);
}

function isDirectHttpVideoCandidate(item) {
  const url = item?.url || '';
  const mime = String(item?.mime || '').toLowerCase();
  const source = String(item?.source || '').toLowerCase();
  const format = normalizeVideoFormat(url, mime);

  if (!/^https?:/i.test(url)) return false;
  if (isRawHlsCandidate(item)) return false;
  if (/\.(m4s|ts|mpd|m3u8|js|css|php|json|xml|html?|png|jpe?g|webp|gif|svg|ico|woff2?|ttf|otf)(\?|#|$)/i.test(url)) return false;
  if (['mp4', 'webm', 'mov', 'm4v', 'ogg'].includes(format)) return true;
  if (/^video\//i.test(mime) || /mp4|webm|quicktime|x-m4v/i.test(mime)) return true;
  if (/rede|performance|video|source/i.test(source) && /mp4|webm|video|media|stream|vod|play/i.test(url)) return true;
  if (/shopee|shp\.ee|shopeemobile|cf\.shopee|mms.*shopee|vod/i.test(url) && /video|mp4|media|stream|vod|play|shopee/i.test(url)) return true;
  return false;
}

function collapseDirectHttpVideoCandidates(items) {
  const fallbackPoster = pickBestPosterFromItems(items);
  const grouped = new Map();

  items.filter(isDirectHttpVideoCandidate).forEach((item) => {
    const key = getDirectHttpVideoGroupKey(item.url);
    const current = {
      ...item,
      type: 'videos',
      format: /shopee|shp\.ee/i.test(item.url + ' ' + (state.pageUrl || '')) ? 'mp4' : normalizeVideoFormat(item.url, item.mime),
      poster: item.poster || fallbackPoster,
      source: /shopee|shp\.ee/i.test(item.url + ' ' + (state.pageUrl || '')) ? 'HTTP Shopee MP4' : 'HTTP vídeo',
      name: item.name || buildDirectVideoName(item),
      alt: item.alt || item.title || 'Vídeo HTTP direto'
    };

    const previous = grouped.get(key);
    if (!previous || scoreDirectHttpCandidate(current) > scoreDirectHttpCandidate(previous)) {
      grouped.set(key, current);
    }
  });

  return [...grouped.values()].sort((a, b) => scoreDirectHttpCandidate(b) - scoreDirectHttpCandidate(a));
}

function getDirectHttpVideoGroupKey(url) {
  if (/shopee|shp\.ee/i.test((state.pageUrl || '') + ' ' + String(url || ''))) {
    return 'shopee-video-principal';
  }

  try {
    const parsed = new URL(url);
    const keepParams = new URLSearchParams();
    ['id', 'video_id', 'vid', 'filename'].forEach((name) => {
      const value = parsed.searchParams.get(name);
      if (value) keepParams.set(name, value);
    });
    const query = keepParams.toString();
    return `${parsed.origin}${parsed.pathname}${query ? '?' + query : ''}`;
  } catch {
    return String(url || '').split(/[?#]/)[0];
  }
}

function scoreDirectHttpCandidate(item) {
  const url = item?.url || '';
  const mime = String(item?.mime || '').toLowerCase();
  let score = scoreVideoCandidate(item);
  if (/^video\//i.test(mime)) score += 1200;
  if (/\.mp4(\?|#|$)/i.test(url) || /mp4/i.test(mime)) score += 1000;
  if (/shopee|shp\.ee|vod/i.test(url + ' ' + (state.pageUrl || ''))) score += 900;
  if (/\.(js|css|php|json|png|jpe?g|webp|svg)(\?|#|$)/i.test(url)) score -= 10000;
  score += Math.min(Number(item?.size || 0) / 50000, 300);
  score += Math.min((Number(item?.width || 0) * Number(item?.height || 0)) / 1000, 3000);
  return score;
}

function buildDirectVideoName(item) {
  const fromUrl = getDisplayName(item.url, 0, 'video-http', normalizeVideoFormat(item.url, item.mime));
  if (fromUrl && !/^video-http/i.test(fromUrl)) return fromUrl;
  const title = String(item.title || item.alt || document.title || 'video-shopee').trim();
  return `${title.replace(/[\\/:*?"<>|]+/g, '-').slice(0, 80) || 'video-shopee'}.mp4`;
}

function isRawHlsCandidate(item) {
  const url = item?.url || '';
  const mime = item?.mime || '';
  const format = normalizeVideoFormat(url, mime);
  return format === 'm3u8' || /\.m3u8(\?|#|$)/i.test(url) || /mpegurl/i.test(mime);
}

function pickBestPosterFromItems(items) {
  const candidates = (items || [])
    .map((item) => item?.poster || '')
    .filter((poster) => /^(https?:|data:image\/|blob:)/i.test(poster));

  if (!candidates.length) return '';

  const scored = candidates.map((url, index) => {
    let score = 1000 - index;
    if (/video|poster|thumb|thumbnail|preview/i.test(url)) score += 5000;
    if (/logo|sprite|icon|avatar|brand/i.test(url)) score -= 5000;
    return { url, score };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored[0]?.url || '';
}

async function collapseHlsCandidates(items) {
  const hlsItems = items.filter(isRawHlsCandidate);

  // A aba Vídeos agora é focada somente em HLS/M3U8.
  // Itens genéricos do player, scripts, PHP, JS, CSS e URLs auxiliares continuam sendo usados
  // apenas como apoio para thumbnail, mas não aparecem como cards no popup.
  if (!hlsItems.length) return [];

  const fallbackPoster = pickBestPosterFromItems(items);
  const resolvedHls = await fetchInPool(hlsItems.slice(0, 60), 4, async (item) => {
    try {
      const resolved = await getHlsDisplayCandidate({ ...item, poster: item.poster || fallbackPoster });
      return { ...resolved, poster: resolved.poster || item.poster || fallbackPoster };
    } catch (error) {
      console.warn('Não foi possível analisar playlist HLS para agrupamento.', error);
      return {
        ...item,
        poster: item.poster || fallbackPoster,
        format: 'm3u8',
        hlsGroupKey: getHlsGroupKey(item.url),
        hlsScore: scoreVideoCandidate(item)
      };
    }
  });

  const grouped = new Map();
  resolvedHls.forEach((item) => {
    const key = item.hlsGroupKey || getHlsGroupKey(item.url);
    const previous = grouped.get(key);
    if (!previous || scoreHlsCandidate(item) > scoreHlsCandidate(previous)) {
      grouped.set(key, item);
    }
  });

  const collapsedHls = [...grouped.values()].map((item, index) => ({
    ...item,
    type: 'videos',
    format: 'm3u8',
    poster: item.poster || fallbackPoster,
    source: item.hlsVariantCount > 1 ? `HLS melhor qualidade (${item.hlsVariantCount} opções)` : 'HLS melhor qualidade',
    name: item.name || getDisplayName(item.url, index, 'video-hls', 'm3u8'),
    alt: item.alt || 'Playlist HLS agrupada em melhor qualidade'
  }));

  return mergeVideoCandidates(collapsedHls).filter(isRawHlsCandidate);
}

async function getHlsDisplayCandidate(item) {
  const info = await analyzeHlsForDisplay(item.url);
  const finalUrl = info.bestUrl || item.url;
  const detected = normalizeVideoFormat(finalUrl, item.mime);
  return {
    ...item,
    url: finalUrl,
    format: 'm3u8',
    width: info.width || item.width || 0,
    height: info.height || item.height || 0,
    pixels: (info.width || item.width || 0) * (info.height || item.height || 0),
    mime: item.mime || 'application/vnd.apple.mpegurl',
    name: getDisplayName(finalUrl, 0, 'video-hls', detected || 'm3u8'),
    hlsScore: info.score || scoreVideoCandidate(item),
    hlsGroupKey: info.groupKey || getHlsGroupKey(item.url),
    hlsVariantCount: info.variantCount || 1,
    hlsMasterUrl: info.masterUrl || item.url
  };
}

async function analyzeHlsForDisplay(initialUrl) {
  let currentUrl = initialUrl;
  let masterUrl = initialUrl;
  let bestVariant = null;
  let variantCount = 1;

  for (let depth = 0; depth < 4; depth += 1) {
    const manifest = await fetchTextWithRetry(currentUrl, 2);
    const text = manifest.text;
    currentUrl = manifest.url || currentUrl;

    const variants = listHlsVariants(text, currentUrl);
    if (!variants.length) break;

    variantCount = Math.max(variantCount, variants.length);
    bestVariant = pickBestVariantFromList(variants);
    masterUrl = masterUrl || currentUrl;
    currentUrl = bestVariant.url;
  }

  const width = bestVariant?.width || 0;
  const height = bestVariant?.height || 0;
  const bandwidth = bestVariant?.bandwidth || 0;
  const order = bestVariant?.order || 0;
  const score = (width * height) || bandwidth || order || scoreVideoCandidate({ url: currentUrl, mime: 'application/vnd.apple.mpegurl' });

  return {
    bestUrl: currentUrl,
    width,
    height,
    bandwidth,
    score,
    variantCount,
    masterUrl,
    groupKey: getHlsGroupKey(initialUrl)
  };
}

function getHlsGroupKey(url) {
  // No Mercado Livre, normalmente index.m3u8 e as variantes fazem parte do mesmo vídeo do anúncio.
  // Agrupar tudo em uma única chave evita que o popup mostre várias miniaturas do mesmo vídeo.
  if (/mercadolivre|mercadolibre/i.test(state.pageUrl || '')) {
    return 'mercado-livre-hls-principal';
  }

  try {
    const parsed = new URL(url);
    const directory = parsed.pathname.replace(/\/[^/]*$/, '/');
    return `${parsed.origin}${directory}`;
  } catch {
    return String(url || '').replace(/\/[^/]*$/, '/');
  }
}

function scoreHlsCandidate(item) {
  const url = item?.url || '';
  const width = Number(item?.width || 0);
  const height = Number(item?.height || 0);
  let score = Number(item?.hlsScore || 0) || (width * height) || scoreVideoCandidate(item);
  if (/\.m3u8(\?|#|$)/i.test(url)) score += 1000;
  if (/\/index\.m3u8(\?|#|$)/i.test(url)) score -= 75;
  if (/rede|performance/i.test(item?.source || '')) score += 25;
  return score;
}

function isGenericVideoCandidate(item) {
  const url = item?.url || '';
  const format = normalizeVideoFormat(url, item?.mime || '');
  if (['mp4', 'webm', 'mov', 'm4v', 'ogg'].includes(format)) return false;
  if (/^blob:/i.test(url)) return true;
  if (/\.(m4s|ts)(\?|#|$)/i.test(url)) return true;
  if (format === 'video' && /script|atributo|src|href|js|player/i.test(item?.source || '')) return true;
  return false;
}

function scoreVideoCandidate(item) {
  const url = item?.url || '';
  let score = 0;
  if (/^https?:/i.test(url)) score += 1000;
  if (/\.mp4(\?|#|$)/i.test(url)) score += 500;
  if (/\.webm(\?|#|$)/i.test(url)) score += 420;
  if (/\.(mov|m4v)(\?|#|$)/i.test(url)) score += 380;
  if (/\.m3u8(\?|#|$)/i.test(url)) score += 260;
  if (/\.mpd(\?|#|$)/i.test(url)) score += 170;
  if (/\.(m4s|ts)(\?|#|$)/i.test(url)) score -= 350;
  if (/^blob:/i.test(url)) score -= 500;
  if (/rede|performance/i.test(item?.source || '')) score += 80;
  if (/script|meta|atributo/i.test(item?.source || '')) score += 60;
  score += Math.min(Number(item?.size || 0) / 100000, 100);
  return score;
}

async function loadCurrentMedia(force = false) {
  if (!force && state.loaded[state.type]) {
    applyFilters();
    return;
  }

  if (state.type === 'videos') await loadVideos();
  else await loadImages();
}

async function loadImages() {
  state.loading = true;
  state.images = [];
  state.filtered = [];
  state.selected.images.clear();
  state.loaded.images = false;
  updateCounts();
  els.gallery.innerHTML = '<div class="empty">Buscando imagens na página...</div>';
  setMessage('Lendo imagens da página atual...');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error('Não foi possível identificar a aba atual.');
    state.tabId = tab.id;
    state.pageUrl = tab.url || '';

    const injected = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: collectImagesInPage
    });

    const rawImages = injected?.[0]?.result || [];

    const enriched = await Promise.all(rawImages.map(async (item, index) => {
      const detected = normalizeImageFormat(item.url, item.mime);
      const loadedSize = (!item.width || !item.height) ? await getImageSize(item.url) : null;
      const width = item.width || loadedSize?.width || 0;
      const height = item.height || loadedSize?.height || 0;
      const auxiliary = isAuxiliaryImage(item, detected, width, height);
      return {
        id: `img-${index}-${btoa(unescape(encodeURIComponent(item.url))).slice(0, 18)}`,
        type: 'images',
        url: item.url,
        source: item.source || 'page',
        width,
        height,
        pixels: width * height,
        format: detected,
        name: getDisplayName(item.url, index, 'imagem', detected),
        alt: item.alt || '',
        auxiliary: auxiliary.auxiliary,
        auxiliaryReason: auxiliary.reason
      };
    }));

    state.images = enriched.sort((a, b) => (b.pixels || 0) - (a.pixels || 0));
    state.loaded.images = true;
    applyFilters();

    const auxCount = state.images.filter((img) => img.auxiliary).length;
    const mainCount = state.images.length - auxCount;
    const auxText = auxCount ? ` ${auxCount} auxiliar(es) ocultas pelo filtro inteligente.` : '';
    setMessage(`${mainCount} imagem(ns) principais encontradas.${auxText}`, 'success');
  } catch (error) {
    console.error(error);
    els.gallery.innerHTML = '<div class="empty">Não foi possível ler as imagens desta página.</div>';
    setMessage(error.message || 'Erro ao buscar imagens.', 'error');
  } finally {
    state.loading = false;
  }
}

async function loadVideos() {
  state.loading = true;
  state.videos = [];
  state.filtered = [];
  state.selected.videos.clear();
  state.loaded.videos = false;
  updateCounts();
  els.gallery.innerHTML = '<div class="empty">Buscando vídeos na página...</div>';
  setMessage('Lendo vídeos da página atual...');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error('Não foi possível identificar a aba atual.');
    state.tabId = tab.id;
    state.pageUrl = tab.url || '';

    const injected = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      func: collectVideosInPage
    });

    const pageVideos = (injected || []).flatMap((frameResult) => frameResult?.result || []);
    let capturedVideos = [];
    try {
      const capturedResponse = await chrome.runtime.sendMessage({ type: 'getCapturedVideos', tabId: tab.id });
      capturedVideos = capturedResponse?.ok ? (capturedResponse.items || []) : [];
    } catch {}

    const rawVideos = await prepareVideoCandidates(pageVideos, capturedVideos);

    const enriched = await Promise.all(rawVideos.map(async (item, index) => {
      const detected = normalizeVideoFormat(item.url, item.mime);
      const loadedMeta = (!item.width || !item.height) ? await getVideoMetadata(item.url) : null;
      const width = item.width || loadedMeta?.width || 0;
      const height = item.height || loadedMeta?.height || 0;
      const duration = loadedMeta?.duration || 0;
      return {
        id: `vid-${index}-${btoa(unescape(encodeURIComponent(item.url))).slice(0, 18)}`,
        type: 'videos',
        url: item.url,
        source: item.source || 'page',
        width,
        height,
        pixels: width * height,
        format: detected,
        mime: item.mime || '',
        duration,
        size: Number(item.size || 0) || 0,
        poster: item.poster || '',
        hlsScore: Number(item.hlsScore || 0) || 0,
        hlsVariantCount: Number(item.hlsVariantCount || 0) || 0,
        hlsMasterUrl: item.hlsMasterUrl || '',
        name: item.name || getDisplayName(item.url, index, 'video', detected),
        alt: item.title || item.alt || ''
      };
    }));

    state.videos = enriched.sort((a, b) => (scoreVideoCandidate(b) + (b.hlsScore || 0)) - (scoreVideoCandidate(a) + (a.hlsScore || 0)) || (b.pixels || 0) - (a.pixels || 0));
    state.loaded.videos = true;
    applyFilters();

    setMessage(`${state.videos.length} vídeo(s) encontrados.`, 'success');
  } catch (error) {
    console.error(error);
    els.gallery.innerHTML = '<div class="empty">Não foi possível ler os vídeos desta página.</div>';
    setMessage(error.message || 'Erro ao buscar vídeos.', 'error');
  } finally {
    state.loading = false;
  }
}

function passesFilters(item) {
  const text = els.urlFilter.value.trim().toLowerCase();
  const format = els.formatFilter.value;
  const minWidth = Number(els.minWidth.value || 0);
  const minHeight = Number(els.minHeight.value || 0);
  const minPixels = Number(els.minPixels.value || 0);

  if (state.type === 'images' && item.auxiliary && !shouldShowAuxiliaryImages()) return false;
  if (text && !`${item.url} ${item.name} ${item.alt} ${item.auxiliaryReason || ''}`.toLowerCase().includes(text)) return false;
  if (format) {
    if (state.type === 'images' && format === 'jpg' && !['jpg', 'jpeg'].includes(item.format)) return false;
    else if (state.type === 'videos' && format === 'http' && !isDirectHttpVideoCandidate(item)) return false;
    else if (state.type === 'videos' && format === 'video' && FORMAT_OPTIONS.videos.some(([value]) => value && value !== 'video' && value === item.format)) return false;
    else if (!(state.type === 'images' && format === 'jpg') && !(state.type === 'videos' && ['video', 'http'].includes(format)) && item.format !== format) return false;
  }
  if (minWidth && item.width < minWidth) return false;
  if (minHeight && item.height < minHeight) return false;
  if (minPixels && item.pixels < minPixels) return false;
  return true;
}

function applyFilters() {
  state.filtered = currentItems().filter(passesFilters);
  renderGallery();
  updateCounts();
}

function renderGallery() {
  const items = currentItems();
  const selected = currentSelected();
  els.gallery.innerHTML = '';

  if (!items.length) {
    els.gallery.innerHTML = `<div class="empty">Nenhum(a) ${itemLabel(false)} encontrado(a).</div>`;
    return;
  }

  if (!state.filtered.length) {
    els.gallery.innerHTML = '<div class="empty">Nenhum item corresponde aos filtros aplicados.</div>';
    return;
  }

  const fragment = document.createDocumentFragment();

  state.filtered.forEach((item) => {
    const card = document.createElement('article');
    card.className = `card ${state.type === 'videos' ? 'video-card' : ''}`;
    card.title = item.url;

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = selected.has(item.id);
    checkbox.addEventListener('change', () => {
      if (checkbox.checked) selected.add(item.id);
      else selected.delete(item.id);
      updateCounts();
    });

    const thumbWrap = document.createElement('div');
    thumbWrap.className = 'thumb-wrap';

    const preview = createPreviewElement(item);

    const badges = document.createElement('div');
    badges.className = 'badges';
    badges.innerHTML = `
      <span class="badge ${item.format === 'webp' ? 'webp' : ''}">${getFormatBadgeLabel(item)}</span>
      <span class="badge">${item.width || '?'}×${item.height || '?'}</span>
      ${state.type === 'images' && item.auxiliary ? `<span class="badge aux">AUX</span>` : ''}
      ${state.type === 'videos' && item.duration ? `<span class="badge">${formatDuration(item.duration)}</span>` : ''}
    `;

    thumbWrap.appendChild(preview);
    thumbWrap.appendChild(badges);

    const meta = document.createElement('div');
    meta.className = 'meta';

    const filename = document.createElement('div');
    filename.className = 'filename';
    filename.textContent = item.name;

    const source = document.createElement('div');
    source.className = 'source';
    source.textContent = item.source;

    const actions = document.createElement('div');
    actions.className = 'card-actions';

    const downloadBtn = document.createElement('button');
    downloadBtn.className = 'ghost-btn';
    downloadBtn.textContent = 'Baixar';
    downloadBtn.addEventListener('click', () => downloadMedia([item]));

    actions.appendChild(downloadBtn);
    meta.appendChild(filename);
    meta.appendChild(source);
    meta.appendChild(actions);

    card.appendChild(checkbox);
    card.appendChild(thumbWrap);
    card.appendChild(meta);
    fragment.appendChild(card);
  });

  els.gallery.appendChild(fragment);
}

function createPreviewElement(item) {
  if (state.type === 'videos') {
    if (item.poster) {
      const img = document.createElement('img');
      img.src = item.poster;
      img.alt = item.alt || item.name;
      img.loading = 'lazy';
      img.referrerPolicy = 'no-referrer-when-downgrade';
      return img;
    }

    if (/^(https?:|blob:|data:video\/)/i.test(item.url) && item.format !== 'm3u8') {
      const video = document.createElement('video');
      video.src = item.url;
      video.muted = true;
      video.preload = 'metadata';
      video.playsInline = true;
      video.controls = false;
      return video;
    }

    const placeholder = document.createElement('div');
    placeholder.className = 'video-placeholder';
    placeholder.textContent = '▶';
    return placeholder;
  }

  const img = document.createElement('img');
  img.src = item.url;
  img.alt = item.alt || item.name;
  img.loading = 'lazy';
  img.referrerPolicy = 'no-referrer-when-downgrade';
  return img;
}

function getFormatBadgeLabel(item) {
  if (state.type === 'videos' && isDirectHttpVideoCandidate(item) && item.format === 'video') return 'HTTP';
  return String(item.format || (state.type === 'videos' ? 'VIDEO' : 'IMG')).toUpperCase();
}

function formatDuration(seconds) {
  const total = Math.round(seconds);
  const mins = Math.floor(total / 60);
  const secs = total % 60;
  return `${mins}:${String(secs).padStart(2, '0')}`;
}

function updateCounts() {
  const items = currentItems();
  const selected = currentSelected();
  const filteredOut = Math.max(0, items.length - state.filtered.length);
  els.matchingCount.textContent = `${state.filtered.length} exibida(s)`;
  els.filteredCount.textContent = `${filteredOut} filtrada(s)`;
  els.selectedCount.textContent = `${selected.size} selecionada(s)`;

  const visibleIds = new Set(state.filtered.map((item) => item.id));
  const selectedVisibleCount = [...visibleIds].filter((id) => selected.has(id)).length;
  els.selectAllVisible.checked = state.filtered.length > 0 && selectedVisibleCount === state.filtered.length;
  els.selectAllVisible.indeterminate = selectedVisibleCount > 0 && selectedVisibleCount < state.filtered.length;
  els.downloadSelectedBtn.disabled = selected.size === 0;
  els.downloadVisibleBtn.disabled = state.filtered.length === 0;
}

function clearFilters() {
  els.urlFilter.value = '';
  els.formatFilter.value = '';
  els.minWidth.value = '';
  els.minHeight.value = '';
  els.minPixels.value = '';
  applyFilters();
}

function getSafeFilename(item, index, forceImageOutput = false) {
  const fallbackPrefix = item.type === 'videos' ? 'video' : 'imagem';
  const fallbackExt = item.type === 'videos' ? (item.format || 'mp4') : (item.format || 'jpg');
  let name = item.name || `${fallbackPrefix}-${String(index + 1).padStart(3, '0')}.${fallbackExt}`;
  name = name.split('?')[0].split('#')[0];
  name = name.replace(/[\\/:*?"<>|]+/g, '-').replace(/\s+/g, ' ').trim();

  const extMatch = name.match(/\.([a-z0-9]{2,5})$/i);
  const ext = extMatch ? extMatch[1].toLowerCase() : '';

  if (item.type === 'images') {
    const shouldBeJpg = item.format === 'webp';

    if (shouldBeJpg) {
      name = extMatch ? name.replace(/\.[a-z0-9]{2,5}$/i, '.jpg') : `${name}.jpg`;
    } else if (forceImageOutput && !['jpg', 'jpeg', 'png'].includes(ext)) {
      name = extMatch ? name.replace(/\.[a-z0-9]{2,5}$/i, '.jpg') : `${name}.jpg`;
    } else if (!ext) {
      name = `${name}.${item.format === 'jpeg' ? 'jpg' : item.format || 'jpg'}`;
    }

    return `imagens/${String(index + 1).padStart(3, '0')}-${name}`;
  }

  if (!ext) {
    name = `${name}.${item.format && item.format !== 'video' ? item.format : 'mp4'}`;
  }

  return `videos/${String(index + 1).padStart(3, '0')}-${name}`;
}

function isHlsItem(item) {
  return item?.type === 'videos'
    && (item.format === 'm3u8' || /\.m3u8(\?|#|$)/i.test(item.url || '') || /mpegurl/i.test(item.mime || ''));
}

async function downloadHlsVideo(item, requestedFilename) {
  setMessage('Lendo manifesto HLS (.m3u8)...');
  const hls = await buildHlsBlob(item.url, (progress) => {
    if (progress.phase === 'manifest') setMessage('Lendo manifesto HLS (.m3u8)...');
    if (progress.phase === 'segments') setMessage(`Baixando segmentos ${progress.done}/${progress.total}...`);
    if (progress.phase === 'transmux') setMessage('Convertendo HLS para MP4...');
    if (progress.phase === 'joining') setMessage('Finalizando arquivo MP4...');
  }, item);

  const filename = withHlsExtension(requestedFilename, hls.extension);
  const objectUrl = URL.createObjectURL(hls.blob);

  try {
    await chrome.downloads.download({
      url: objectUrl,
      filename,
      saveAs: false,
      conflictAction: 'uniquify'
    });
  } finally {
    setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
  }

  return { ok: true, extension: hls.extension, segmentCount: hls.segmentCount };
}

function withHlsExtension(filename, extension) {
  const ext = extension || 'ts';
  const safe = filename || `videos/video.${ext}`;
  return safe.match(/\.[a-z0-9]{2,5}$/i)
    ? safe.replace(/\.[a-z0-9]{2,5}$/i, `.${ext}`)
    : `${safe}.${ext}`;
}

async function buildHlsBlob(initialUrl, onProgress = () => {}, item = {}) {
  onProgress({ phase: 'manifest' });
  const media = await resolveHlsMediaPlaylist(initialUrl);

  if (!media.segments.length) {
    throw new Error('O manifesto HLS não possui segmentos de vídeo baixáveis.');
  }

  if (media.encrypted) {
    throw new Error('Este HLS possui criptografia. A extensão não remove proteção nem DRM.');
  }

  if (media.hasByteRange) {
    throw new Error('Este HLS usa BYTERANGE. Esta versão ainda não baixa playlists com BYTERANGE.');
  }

  const parts = [];
  let done = 0;
  const total = media.segments.length + (media.mapUrl ? 1 : 0);

  if (media.mapUrl) {
    onProgress({ phase: 'segments', done, total });
    parts.push(await fetchArrayBufferWithRetry(media.mapUrl));
    done += 1;
    onProgress({ phase: 'segments', done, total });
  }

  const buffers = await fetchInPool(media.segments, 5, async (url, index) => {
    const buffer = await fetchArrayBufferWithRetry(url);
    done += 1;
    onProgress({ phase: 'segments', done, total, current: index + 1 });
    return buffer;
  });

  parts.push(...buffers);

  if (media.extension === 'mp4') {
    onProgress({ phase: 'joining' });
    return {
      blob: new Blob(parts, { type: 'video/mp4' }),
      extension: 'mp4',
      segmentCount: media.segments.length
    };
  }

  onProgress({ phase: 'transmux' });
  const mp4Buffer = transmuxMpegTsToMp4(parts, {
    width: media.width || item.width || 0,
    height: media.height || item.height || 0
  });
  onProgress({ phase: 'joining' });

  return {
    blob: new Blob([mp4Buffer], { type: 'video/mp4' }),
    extension: 'mp4',
    segmentCount: media.segments.length
  };
}
async function resolveHlsMediaPlaylist(initialUrl) {
  let currentUrl = initialUrl;
  let text = '';
  let selectedVariant = null;

  for (let depth = 0; depth < 4; depth += 1) {
    const manifest = await fetchTextWithRetry(currentUrl);
    text = manifest.text;
    currentUrl = manifest.url || currentUrl;

    const variant = pickBestHlsVariant(text, currentUrl);
    if (!variant) break;
    selectedVariant = variant;
    currentUrl = variant.url;
  }

  const parsed = parseMediaPlaylist(text, currentUrl);
  return {
    ...parsed,
    width: selectedVariant?.width || 0,
    height: selectedVariant?.height || 0,
    bandwidth: selectedVariant?.bandwidth || 0
  };
}

async function fetchTextWithRetry(url, attempts = 3) {
  let lastError;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      const response = await fetch(url, {
        credentials: 'include',
        cache: 'no-store'
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return { text: await response.text(), url: response.url || url };
    } catch (error) {
      lastError = error;
      await sleep(250 * attempt);
    }
  }
  throw new Error(`Não foi possível ler o manifesto HLS: ${lastError?.message || lastError}`);
}

async function fetchArrayBufferWithRetry(url, attempts = 3) {
  let lastError;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      const response = await fetch(url, {
        credentials: 'include',
        cache: 'no-store'
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.arrayBuffer();
    } catch (error) {
      lastError = error;
      await sleep(250 * attempt);
    }
  }
  throw new Error(`Falha ao baixar segmento: ${lastError?.message || lastError}`);
}

function listHlsVariants(text, baseUrl) {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const variants = [];

  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    if (!line.startsWith('#EXT-X-STREAM-INF')) continue;

    const attrs = parseHlsAttributes(line.split(':').slice(1).join(':'));
    const nextUrl = findNextHlsUrl(lines, i + 1);
    if (!nextUrl) continue;

    const resolution = String(attrs.RESOLUTION || '').split('x').map((value) => Number(value) || 0);
    const bandwidth = Number(attrs.BANDWIDTH || attrs['AVERAGE-BANDWIDTH'] || 0) || 0;
    const width = resolution[0] || 0;
    const height = resolution[1] || 0;
    const order = variants.length + 1;

    variants.push({
      url: resolveUrl(nextUrl, baseUrl),
      width,
      height,
      bandwidth,
      order,
      score: (width * height) || bandwidth || order
    });
  }

  return variants;
}

function pickBestVariantFromList(variants) {
  if (!variants.length) return null;
  return [...variants].sort((a, b) => b.score - a.score || b.bandwidth - a.bandwidth || b.order - a.order)[0];
}

function pickBestHlsVariant(text, baseUrl) {
  return pickBestVariantFromList(listHlsVariants(text, baseUrl));
}

function findNextHlsUrl(lines, startIndex) {
  for (let i = startIndex; i < lines.length; i += 1) {
    const line = lines[i];
    if (!line || line.startsWith('#')) continue;
    return line;
  }
  return '';
}

function parseMediaPlaylist(text, baseUrl) {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const segments = [];
  let mapUrl = '';
  let encrypted = false;
  let hasByteRange = false;

  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];

    if (line.startsWith('#EXT-X-KEY')) {
      const attrs = parseHlsAttributes(line.split(':').slice(1).join(':'));
      const method = String(attrs.METHOD || '').toUpperCase();
      if (method && method !== 'NONE') encrypted = true;
    }

    if (line.startsWith('#EXT-X-BYTERANGE')) {
      hasByteRange = true;
    }

    if (line.startsWith('#EXT-X-MAP')) {
      const attrs = parseHlsAttributes(line.split(':').slice(1).join(':'));
      if (attrs.URI) mapUrl = resolveUrl(attrs.URI, baseUrl);
    }

    if (!line || line.startsWith('#')) continue;
    segments.push(resolveUrl(line, baseUrl));
  }

  const hasFmp4 = Boolean(mapUrl) || segments.some((url) => /\.(m4s|mp4|cmfv|fmp4)(\?|#|$)/i.test(url));

  return {
    segments,
    mapUrl,
    encrypted,
    hasByteRange,
    extension: hasFmp4 ? 'mp4' : 'ts'
  };
}

function parseHlsAttributes(text) {
  const attrs = {};
  const re = /([A-Z0-9-]+)=((?:"[^"]*")|[^,]*)/gi;
  let match;
  while ((match = re.exec(text || '')) !== null) {
    const key = match[1];
    let value = match[2] || '';
    if (value.startsWith('"') && value.endsWith('"')) value = value.slice(1, -1);
    attrs[key] = value;
  }
  return attrs;
}

function resolveUrl(url, baseUrl) {
  const clean = String(url || '')
    .trim()
    .replace(/^['"]|['"]$/g, '')
    .replace(/&amp;/g, '&');
  return new URL(clean, baseUrl).href;
}


function transmuxMpegTsToMp4(buffers, options = {}) {
  const parsed = parseMpegTsBuffers(buffers);
  if (!parsed.video.samples.length && !parsed.audio.samples.length) {
    throw new Error('Não foi possível extrair áudio/vídeo dos segmentos TS.');
  }
  if (parsed.video.samples.length && (!parsed.video.sps || !parsed.video.pps)) {
    throw new Error('Não foi possível localizar SPS/PPS do vídeo H.264 para gerar MP4.');
  }
  return buildMp4FromElementaryStreams(parsed, options);
}

function parseMpegTsBuffers(buffers) {
  const bytes = concatUint8Arrays(buffers.map((buffer) => new Uint8Array(buffer)));
  const syncOffset = findTsSyncOffset(bytes);
  if (syncOffset < 0) throw new Error('Segmento TS inválido: byte de sincronismo não encontrado.');

  let pmtPid = -1;
  let videoPid = -1;
  let audioPid = -1;

  for (let offset = syncOffset; offset + 188 <= bytes.length; offset += 188) {
    if (bytes[offset] !== 0x47) continue;
    const packet = parseTsPacket(bytes.subarray(offset, offset + 188));
    if (!packet || !packet.payload.length) continue;

    if (packet.pid === 0) {
      const patPid = parsePatForPmtPid(packet.payload, packet.payloadUnitStart);
      if (patPid >= 0) pmtPid = patPid;
    } else if (packet.pid === pmtPid) {
      const streams = parsePmtForStreams(packet.payload, packet.payloadUnitStart);
      if (streams.videoPid >= 0) videoPid = streams.videoPid;
      if (streams.audioPid >= 0) audioPid = streams.audioPid;
      if (videoPid >= 0 || audioPid >= 0) break;
    }
  }

  if (videoPid < 0 && audioPid < 0) {
    throw new Error('Não foi possível encontrar trilhas de vídeo ou áudio no TS.');
  }

  const builders = new Map();
  if (videoPid >= 0) builders.set(videoPid, { pid: videoPid, type: 'video', parts: [], pes: [] });
  if (audioPid >= 0) builders.set(audioPid, { pid: audioPid, type: 'audio', parts: [], pes: [] });

  for (let offset = syncOffset; offset + 188 <= bytes.length; offset += 188) {
    if (bytes[offset] !== 0x47) continue;
    const packet = parseTsPacket(bytes.subarray(offset, offset + 188));
    if (!packet || !builders.has(packet.pid) || !packet.payload.length) continue;

    const builder = builders.get(packet.pid);
    if (packet.payloadUnitStart && builder.parts.length) {
      const pes = parsePes(concatUint8Arrays(builder.parts));
      if (pes && pes.payload.length) builder.pes.push(pes);
      builder.parts = [];
    }
    builder.parts.push(packet.payload);
  }

  builders.forEach((builder) => {
    if (builder.parts.length) {
      const pes = parsePes(concatUint8Arrays(builder.parts));
      if (pes && pes.payload.length) builder.pes.push(pes);
      builder.parts = [];
    }
  });

  const video = parseH264PesList(builders.get(videoPid)?.pes || []);
  const audio = parseAacPesList(builders.get(audioPid)?.pes || []);
  return { video, audio };
}

function findTsSyncOffset(bytes) {
  for (let offset = 0; offset < Math.min(188, bytes.length); offset += 1) {
    let ok = true;
    for (let i = 0; i < 5; i += 1) {
      if (bytes[offset + i * 188] !== 0x47) {
        ok = false;
        break;
      }
    }
    if (ok) return offset;
  }
  return -1;
}

function parseTsPacket(packet) {
  if (packet.length !== 188 || packet[0] !== 0x47) return null;
  const payloadUnitStart = Boolean(packet[1] & 0x40);
  const pid = ((packet[1] & 0x1f) << 8) | packet[2];
  const adaptationFieldControl = (packet[3] & 0x30) >> 4;
  let offset = 4;

  if (adaptationFieldControl === 0 || adaptationFieldControl === 2) {
    return { pid, payloadUnitStart, payload: new Uint8Array(0) };
  }

  if (adaptationFieldControl === 3) {
    const adaptationLength = packet[offset] || 0;
    offset += 1 + adaptationLength;
  }

  if (offset >= 188) return { pid, payloadUnitStart, payload: new Uint8Array(0) };
  return { pid, payloadUnitStart, payload: packet.subarray(offset) };
}

function payloadWithoutPointer(payload, payloadUnitStart) {
  if (!payloadUnitStart) return payload;
  const pointer = payload[0] || 0;
  return payload.subarray(1 + pointer);
}

function parsePatForPmtPid(payload, payloadUnitStart) {
  const section = payloadWithoutPointer(payload, payloadUnitStart);
  if (section.length < 12 || section[0] !== 0x00) return -1;
  const sectionLength = ((section[1] & 0x0f) << 8) | section[2];
  const end = Math.min(section.length, 3 + sectionLength - 4);

  for (let offset = 8; offset + 4 <= end; offset += 4) {
    const programNumber = (section[offset] << 8) | section[offset + 1];
    const pid = ((section[offset + 2] & 0x1f) << 8) | section[offset + 3];
    if (programNumber !== 0) return pid;
  }
  return -1;
}

function parsePmtForStreams(payload, payloadUnitStart) {
  const section = payloadWithoutPointer(payload, payloadUnitStart);
  const result = { videoPid: -1, audioPid: -1 };
  if (section.length < 12 || section[0] !== 0x02) return result;

  const sectionLength = ((section[1] & 0x0f) << 8) | section[2];
  const programInfoLength = ((section[10] & 0x0f) << 8) | section[11];
  let offset = 12 + programInfoLength;
  const end = Math.min(section.length, 3 + sectionLength - 4);

  while (offset + 5 <= end) {
    const streamType = section[offset];
    const elementaryPid = ((section[offset + 1] & 0x1f) << 8) | section[offset + 2];
    const esInfoLength = ((section[offset + 3] & 0x0f) << 8) | section[offset + 4];

    if (streamType === 0x1b && result.videoPid < 0) result.videoPid = elementaryPid; // H.264
    if (streamType === 0x0f && result.audioPid < 0) result.audioPid = elementaryPid; // AAC ADTS
    offset += 5 + esInfoLength;
  }

  return result;
}

function parsePes(data) {
  if (data.length < 9 || data[0] !== 0x00 || data[1] !== 0x00 || data[2] !== 0x01) return null;
  const flags = data[7] || 0;
  const headerLength = data[8] || 0;
  let pts = null;
  let dts = null;

  if ((flags & 0x80) && data.length >= 14) {
    pts = readPtsDts(data, 9);
    dts = pts;
  }
  if ((flags & 0x40) && data.length >= 19) {
    dts = readPtsDts(data, 14);
  }

  const payloadOffset = 9 + headerLength;
  if (payloadOffset >= data.length) return null;
  return {
    pts: pts ?? 0,
    dts: dts ?? pts ?? 0,
    payload: data.subarray(payloadOffset)
  };
}

function readPtsDts(data, offset) {
  const p32_30 = (data[offset] >> 1) & 0x07;
  const p29_15 = (data[offset + 1] << 7) | (data[offset + 2] >> 1);
  const p14_0 = (data[offset + 3] << 7) | (data[offset + 4] >> 1);
  return (p32_30 * 0x40000000) + (p29_15 * 0x8000) + p14_0;
}

function parseH264PesList(pesList) {
  const samples = [];
  let sps = null;
  let pps = null;

  pesList.forEach((pes) => {
    const nalUnits = splitAnnexBNalUnits(pes.payload);
    const sampleNals = [];
    let keyframe = false;

    nalUnits.forEach((nal) => {
      if (!nal.length) return;
      const nalType = nal[0] & 0x1f;
      if (nalType === 7) {
        if (!sps) sps = copyU8(nal);
        return;
      }
      if (nalType === 8) {
        if (!pps) pps = copyU8(nal);
        return;
      }
      if (nalType === 9) return; // AUD não precisa ir no MP4
      if (nalType === 5) keyframe = true;
      sampleNals.push(copyU8(nal));
    });

    if (!sampleNals.length) return;
    samples.push({
      pts: pes.pts || pes.dts || 0,
      dts: pes.dts || pes.pts || 0,
      nals: sampleNals,
      keyframe
    });
  });

  samples.sort((a, b) => a.dts - b.dts || a.pts - b.pts);
  normalizeVideoTiming(samples);

  return { samples, sps, pps, timescale: 90000 };
}

function splitAnnexBNalUnits(data) {
  const starts = [];
  for (let i = 0; i + 3 < data.length; i += 1) {
    if (data[i] === 0x00 && data[i + 1] === 0x00 && data[i + 2] === 0x01) {
      starts.push({ start: i, header: 3 });
      i += 2;
    } else if (i + 4 < data.length && data[i] === 0x00 && data[i + 1] === 0x00 && data[i + 2] === 0x00 && data[i + 3] === 0x01) {
      starts.push({ start: i, header: 4 });
      i += 3;
    }
  }

  const units = [];
  for (let i = 0; i < starts.length; i += 1) {
    const start = starts[i].start + starts[i].header;
    const end = i + 1 < starts.length ? starts[i + 1].start : data.length;
    let unit = data.subarray(start, end);
    while (unit.length && unit[unit.length - 1] === 0x00) unit = unit.subarray(0, unit.length - 1);
    if (unit.length) units.push(unit);
  }
  return units;
}

function normalizeVideoTiming(samples) {
  if (!samples.length) return;
  const firstDts = samples[0].dts || 0;
  samples.forEach((sample) => {
    sample.dts = Math.max(0, Math.round((sample.dts || 0) - firstDts));
    sample.pts = Math.max(0, Math.round((sample.pts || sample.dts || 0) - firstDts));
    sample.cts = Math.round(sample.pts - sample.dts);
  });

  const diffs = [];
  for (let i = 0; i + 1 < samples.length; i += 1) {
    const diff = samples[i + 1].dts - samples[i].dts;
    if (diff > 0) diffs.push(diff);
  }
  const fallback = diffs.length ? Math.round(diffs.sort((a, b) => a - b)[Math.floor(diffs.length / 2)]) : 3000;
  samples.forEach((sample, index) => {
    const next = samples[index + 1];
    sample.duration = next && next.dts > sample.dts ? next.dts - sample.dts : fallback;
  });
}

function parseAacPesList(pesList) {
  const samples = [];
  let config = null;
  let sampleRate = 48000;
  let channelCount = 2;
  let firstPts = null;
  let nextDts = 0;

  pesList.forEach((pes) => {
    const data = pes.payload;
    let offset = 0;
    if (firstPts === null) {
      firstPts = pes.pts || pes.dts || 0;
      nextDts = 0;
    }

    while (offset + 7 <= data.length) {
      if (data[offset] !== 0xff || (data[offset + 1] & 0xf0) !== 0xf0) {
        offset += 1;
        continue;
      }

      const protectionAbsent = data[offset + 1] & 0x01;
      const profileIndex = (data[offset + 2] & 0xc0) >> 6;
      const sampleRateIndex = (data[offset + 2] & 0x3c) >> 2;
      const channelConfig = ((data[offset + 2] & 0x01) << 2) | ((data[offset + 3] & 0xc0) >> 6);
      const frameLength = ((data[offset + 3] & 0x03) << 11) | (data[offset + 4] << 3) | ((data[offset + 5] & 0xe0) >> 5);
      const headerLength = protectionAbsent ? 7 : 9;

      if (!frameLength || offset + frameLength > data.length || frameLength <= headerLength) break;

      const frame = copyU8(data.subarray(offset + headerLength, offset + frameLength));
      const audioObjectType = profileIndex + 1;
      sampleRate = AAC_SAMPLE_RATES[sampleRateIndex] || sampleRate;
      channelCount = channelConfig || channelCount;
      if (!config) config = buildAacAudioSpecificConfig(audioObjectType, sampleRateIndex, channelConfig);

      samples.push({ data: frame, duration: 1024, dts: nextDts, pts: nextDts });
      nextDts += 1024;
      offset += frameLength;
    }
  });

  return { samples, config, sampleRate, channelCount, timescale: sampleRate };
}

const AAC_SAMPLE_RATES = [96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350];

function buildAacAudioSpecificConfig(audioObjectType, sampleRateIndex, channelConfig) {
  return new Uint8Array([
    (audioObjectType << 3) | (sampleRateIndex >> 1),
    ((sampleRateIndex & 1) << 7) | (channelConfig << 3)
  ]);
}

function buildMp4FromElementaryStreams(parsed, options = {}) {
  const tracks = [];
  let trackId = 1;

  if (parsed.video.samples.length) {
    const width = Number(options.width || 0) || 720;
    const height = Number(options.height || 0) || 1280;
    const samples = parsed.video.samples.map((sample) => {
      const data = concatUint8Arrays(sample.nals.map((nal) => concatUint8Arrays([uint32(nal.length), nal])));
      return {
        data,
        duration: Math.max(1, Math.round(sample.duration || 3000)),
        cts: Math.round(sample.cts || 0),
        keyframe: Boolean(sample.keyframe),
        size: data.length,
        offset: 0
      };
    });

    tracks.push({
      id: trackId++,
      type: 'video',
      timescale: 90000,
      duration: samples.reduce((sum, sample) => sum + sample.duration, 0),
      width,
      height,
      samples,
      sps: parsed.video.sps,
      pps: parsed.video.pps
    });
  }

  if (parsed.audio.samples.length && parsed.audio.config) {
    const samples = parsed.audio.samples.map((sample) => ({
      data: sample.data,
      duration: 1024,
      cts: 0,
      keyframe: true,
      size: sample.data.length,
      offset: 0
    }));

    tracks.push({
      id: trackId++,
      type: 'audio',
      timescale: parsed.audio.sampleRate || 48000,
      duration: samples.reduce((sum, sample) => sum + sample.duration, 0),
      sampleRate: parsed.audio.sampleRate || 48000,
      channelCount: parsed.audio.channelCount || 2,
      samples,
      config: parsed.audio.config
    });
  }

  const ftyp = mp4Box('ftyp', ascii('isom'), uint32(0x00000200), ascii('isom'), ascii('iso2'), ascii('avc1'), ascii('mp41'));
  const dummyMoov = makeMoov(tracks, 0);
  const baseOffset = ftyp.length + dummyMoov.length + 8;
  const mediaChunks = [];
  let offset = baseOffset;

  // Intercala por trilha em blocos simples. Cada amostra vira um chunk para simplificar o stco/stsc.
  tracks.forEach((track) => {
    track.samples.forEach((sample) => {
      sample.offset = offset;
      mediaChunks.push(sample.data);
      offset += sample.data.length;
    });
  });

  const moov = makeMoov(tracks, 1000);
  const mdatPayload = concatUint8Arrays(mediaChunks);
  const mdat = mp4Box('mdat', mdatPayload);
  return concatUint8Arrays([ftyp, moov, mdat]).buffer;
}

function makeMoov(tracks, movieTimescale) {
  const duration = Math.max(0, ...tracks.map((track) => Math.ceil(track.duration * movieTimescale / track.timescale)));
  return mp4Box('moov', makeMvhd(movieTimescale, duration, tracks.length + 1), ...tracks.map((track) => makeTrak(track, movieTimescale)));
}

function makeMvhd(timescale, duration, nextTrackId) {
  return mp4FullBox('mvhd', 0, 0,
    uint32(0), uint32(0), uint32(timescale), uint32(duration),
    uint32(0x00010000), uint16(0x0100), uint16(0), uint32(0), uint32(0),
    uint32(0x00010000), uint32(0), uint32(0),
    uint32(0), uint32(0x00010000), uint32(0),
    uint32(0), uint32(0), uint32(0x40000000),
    uint32(0), uint32(0), uint32(0), uint32(0), uint32(0), uint32(0),
    uint32(nextTrackId)
  );
}

function makeTrak(track, movieTimescale) {
  const movieDuration = Math.ceil(track.duration * movieTimescale / track.timescale);
  return mp4Box('trak', makeTkhd(track, movieDuration), makeMdia(track));
}

function makeTkhd(track, movieDuration) {
  const widthFixed = track.type === 'video' ? (track.width << 16) : 0;
  const heightFixed = track.type === 'video' ? (track.height << 16) : 0;
  return mp4FullBox('tkhd', 0, 0x000007,
    uint32(0), uint32(0), uint32(track.id), uint32(0), uint32(movieDuration),
    uint32(0), uint32(0), uint16(0), uint16(0), uint16(track.type === 'audio' ? 0x0100 : 0), uint16(0),
    uint32(0x00010000), uint32(0), uint32(0),
    uint32(0), uint32(0x00010000), uint32(0),
    uint32(0), uint32(0), uint32(0x40000000),
    uint32(widthFixed), uint32(heightFixed)
  );
}

function makeMdia(track) {
  return mp4Box('mdia', makeMdhd(track), makeHdlr(track.type), makeMinf(track));
}

function makeMdhd(track) {
  return mp4FullBox('mdhd', 0, 0,
    uint32(0), uint32(0), uint32(track.timescale), uint32(track.duration), uint16(0), uint16(0)
  );
}

function makeHdlr(type) {
  const handler = type === 'video' ? 'vide' : 'soun';
  const name = type === 'video' ? 'VideoHandler' : 'SoundHandler';
  return mp4FullBox('hdlr', 0, 0, uint32(0), ascii(handler), uint32(0), uint32(0), uint32(0), ascii(name), u8(0));
}

function makeMinf(track) {
  const header = track.type === 'video'
    ? mp4FullBox('vmhd', 0, 0x000001, uint16(0), uint16(0), uint16(0), uint16(0))
    : mp4FullBox('smhd', 0, 0, uint16(0), uint16(0));
  return mp4Box('minf', header, makeDinf(), makeStbl(track));
}

function makeDinf() {
  const url = mp4FullBox('url ', 0, 0x000001);
  const dref = mp4FullBox('dref', 0, 0, uint32(1), url);
  return mp4Box('dinf', dref);
}

function makeStbl(track) {
  const boxes = [makeStsd(track), makeStts(track), makeStsc(), makeStsz(track), makeStco(track)];
  if (track.type === 'video') {
    const ctts = makeCtts(track);
    if (ctts) boxes.splice(2, 0, ctts);
    const stss = makeStss(track);
    if (stss) boxes.splice(2, 0, stss);
  }
  return mp4Box('stbl', ...boxes);
}

function makeStsd(track) {
  const entry = track.type === 'video' ? makeAvc1(track) : makeMp4a(track);
  return mp4FullBox('stsd', 0, 0, uint32(1), entry);
}

function makeAvc1(track) {
  const compressorName = new Uint8Array(32);
  const name = ascii('H.264');
  compressorName[0] = Math.min(31, name.length);
  compressorName.set(name.subarray(0, 31), 1);

  return mp4Box('avc1',
    new Uint8Array(6), uint16(1),
    uint16(0), uint16(0), uint32(0), uint32(0), uint32(0),
    uint16(track.width), uint16(track.height), uint32(0x00480000), uint32(0x00480000), uint32(0), uint16(1),
    compressorName, uint16(0x0018), uint16(0xffff), makeAvcC(track.sps, track.pps)
  );
}

function makeAvcC(sps, pps) {
  if (!sps || sps.length < 4 || !pps) throw new Error('SPS/PPS ausente para AVC.');
  return mp4Box('avcC',
    u8(1, sps[1], sps[2], sps[3], 0xff, 0xe1), uint16(sps.length), sps,
    u8(1), uint16(pps.length), pps
  );
}

function makeMp4a(track) {
  return mp4Box('mp4a',
    new Uint8Array(6), uint16(1),
    uint32(0), uint32(0), uint16(track.channelCount), uint16(16), uint16(0), uint16(0), uint32(track.sampleRate << 16),
    makeEsds(track.config)
  );
}

function makeEsds(config) {
  const decSpecific = concatUint8Arrays([u8(0x05), mp4DescriptorLength(config.length), config]);
  const decConfigPayload = concatUint8Arrays([
    u8(0x40, 0x15), uint24(0), uint32(0), uint32(0), decSpecific
  ]);
  const decConfig = concatUint8Arrays([u8(0x04), mp4DescriptorLength(decConfigPayload.length), decConfigPayload]);
  const slConfig = u8(0x06, 0x01, 0x02);
  const esPayload = concatUint8Arrays([uint16(1), u8(0), decConfig, slConfig]);
  return mp4FullBox('esds', 0, 0, u8(0x03), mp4DescriptorLength(esPayload.length), esPayload);
}

function makeStts(track) {
  const entries = compressRuns(track.samples.map((sample) => sample.duration));
  return mp4FullBox('stts', 0, 0, uint32(entries.length), ...entries.map((entry) => concatUint8Arrays([uint32(entry.count), uint32(entry.value)])));
}

function makeCtts(track) {
  const offsets = track.samples.map((sample) => Math.round(sample.cts || 0));
  if (!offsets.some((value) => value !== 0)) return null;
  const hasNegative = offsets.some((value) => value < 0);
  const entries = compressRuns(offsets);
  return mp4FullBox('ctts', hasNegative ? 1 : 0, 0, uint32(entries.length), ...entries.map((entry) => concatUint8Arrays([uint32(entry.count), hasNegative ? int32(entry.value) : uint32(entry.value)])));
}

function makeStss(track) {
  const keyframes = [];
  track.samples.forEach((sample, index) => {
    if (sample.keyframe) keyframes.push(index + 1);
  });
  if (!keyframes.length || keyframes.length === track.samples.length) return null;
  return mp4FullBox('stss', 0, 0, uint32(keyframes.length), ...keyframes.map(uint32));
}

function makeStsc() {
  return mp4FullBox('stsc', 0, 0, uint32(1), uint32(1), uint32(1), uint32(1));
}

function makeStsz(track) {
  return mp4FullBox('stsz', 0, 0, uint32(0), uint32(track.samples.length), ...track.samples.map((sample) => uint32(sample.size)));
}

function makeStco(track) {
  return mp4FullBox('stco', 0, 0, uint32(track.samples.length), ...track.samples.map((sample) => uint32(sample.offset)));
}

function compressRuns(values) {
  const runs = [];
  values.forEach((value) => {
    const last = runs[runs.length - 1];
    if (last && last.value === value) last.count += 1;
    else runs.push({ count: 1, value });
  });
  return runs;
}

function mp4Box(type, ...payloads) {
  const size = 8 + payloads.reduce((sum, payload) => sum + payload.length, 0);
  const out = new Uint8Array(size);
  writeUint32(out, 0, size);
  out.set(ascii(type), 4);
  let offset = 8;
  payloads.forEach((payload) => {
    out.set(payload, offset);
    offset += payload.length;
  });
  return out;
}

function mp4FullBox(type, version, flags, ...payloads) {
  return mp4Box(type, u8(version, (flags >> 16) & 0xff, (flags >> 8) & 0xff, flags & 0xff), ...payloads);
}

function mp4DescriptorLength(length) {
  const bytes = [];
  let value = length;
  bytes.unshift(value & 0x7f);
  value >>= 7;
  while (value > 0) {
    bytes.unshift((value & 0x7f) | 0x80);
    value >>= 7;
  }
  return new Uint8Array(bytes);
}

function concatUint8Arrays(chunks) {
  const arrays = chunks.map((chunk) => chunk instanceof Uint8Array ? chunk : new Uint8Array(chunk));
  const total = arrays.reduce((sum, chunk) => sum + chunk.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  arrays.forEach((chunk) => {
    out.set(chunk, offset);
    offset += chunk.length;
  });
  return out;
}

function copyU8(data) {
  const out = new Uint8Array(data.length);
  out.set(data);
  return out;
}

function ascii(text) {
  const out = new Uint8Array(text.length);
  for (let i = 0; i < text.length; i += 1) out[i] = text.charCodeAt(i) & 0xff;
  return out;
}

function u8(...values) {
  return new Uint8Array(values.map((value) => value & 0xff));
}

function uint16(value) {
  const out = new Uint8Array(2);
  out[0] = (value >>> 8) & 0xff;
  out[1] = value & 0xff;
  return out;
}

function uint24(value) {
  const out = new Uint8Array(3);
  out[0] = (value >>> 16) & 0xff;
  out[1] = (value >>> 8) & 0xff;
  out[2] = value & 0xff;
  return out;
}

function uint32(value) {
  const out = new Uint8Array(4);
  writeUint32(out, 0, value >>> 0);
  return out;
}

function int32(value) {
  const out = new Uint8Array(4);
  const v = value | 0;
  out[0] = (v >> 24) & 0xff;
  out[1] = (v >> 16) & 0xff;
  out[2] = (v >> 8) & 0xff;
  out[3] = v & 0xff;
  return out;
}

function writeUint32(out, offset, value) {
  out[offset] = (value >>> 24) & 0xff;
  out[offset + 1] = (value >>> 16) & 0xff;
  out[offset + 2] = (value >>> 8) & 0xff;
  out[offset + 3] = value & 0xff;
}

async function fetchInPool(items, concurrency, worker) {
  const results = new Array(items.length);
  let cursor = 0;

  const runners = Array.from({ length: Math.min(concurrency, items.length) }, async () => {
    while (cursor < items.length) {
      const index = cursor;
      cursor += 1;
      results[index] = await worker(items[index], index);
    }
  });

  await Promise.all(runners);
  return results;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function downloadMedia(items) {
  if (!items.length) return;

  let ok = 0;
  let fail = 0;
  let lastError = '';
  const resizeTo1200 = state.type === 'images' && Boolean(els.resize1200?.checked);
  setMessage(`Preparando ${items.length} download(s)...`);

  for (let i = 0; i < items.length; i += 1) {
    const item = items[i];
    try {
      let response;

      if (isHlsItem(item)) {
        response = await downloadHlsVideo(item, getSafeFilename(item, i, resizeTo1200));
      } else {
        response = await chrome.runtime.sendMessage({
          type: item.type === 'videos' ? 'downloadVideo' : 'downloadImage',
          url: item.url,
          filename: getSafeFilename(item, i, resizeTo1200),
          tabId: state.tabId,
          pageUrl: state.pageUrl,
          format: item.format,
          convertWebpToJpg: item.type === 'images',
          resizeTo1200
        });
      }

      if (!response?.ok) throw new Error(response?.error || 'Falha no download');
      ok += 1;
      setMessage(`Baixando ${ok}/${items.length} ${itemLabel(true)}...`);
    } catch (error) {
      console.error(error);
      lastError = error?.message || String(error);
      fail += 1;
    }
  }

  if (fail) {
    const detail = lastError ? ` Último erro: ${lastError}` : '';
    setMessage(`${ok} download(s) iniciados. ${fail} falharam.${detail}`, 'error');
  } else {
    const resizeText = resizeTo1200 ? ' em 1200×1200 px' : '';
    setMessage(`${ok} download(s) iniciados com sucesso${resizeText}.`, 'success');
  }
}

async function switchType(type) {
  if (state.type === type) return;
  state.type = type;
  state.filtered = [];
  updateTabUI();
  applyFilters();
  await loadCurrentMedia(false);
}

els.refreshBtn.addEventListener('click', () => loadCurrentMedia(true));
els.imagesTab.addEventListener('click', () => switchType('images'));
els.videosTab.addEventListener('click', () => switchType('videos'));
[els.urlFilter, els.formatFilter, els.minWidth, els.minHeight, els.minPixels, els.showAuxImages].filter(Boolean).forEach((el) => {
  el.addEventListener('input', applyFilters);
  el.addEventListener('change', applyFilters);
});
els.clearFiltersBtn.addEventListener('click', clearFilters);

els.selectAllVisible.addEventListener('change', () => {
  const selected = currentSelected();
  const shouldSelect = els.selectAllVisible.checked;
  state.filtered.forEach((item) => {
    if (shouldSelect) selected.add(item.id);
    else selected.delete(item.id);
  });
  renderGallery();
  updateCounts();
});

els.downloadSelectedBtn.addEventListener('click', () => {
  const selected = currentSelected();
  const selectedItems = currentItems().filter((item) => selected.has(item.id));
  downloadMedia(selectedItems);
});

els.downloadVisibleBtn.addEventListener('click', () => downloadMedia(state.filtered));

document.addEventListener('DOMContentLoaded', () => {
  updateTabUI();
  loadCurrentMedia(true);
});
